const Utils = {
    formatCurrency: (value) => {
        return new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(value);
    },

    parseCurrency: (str) => {
        if (!str) return 0;
        if (typeof str === 'number') return str;
        return parseFloat(str.replace('R$', '').replace(/\./g, '').replace(',', '.').trim());
    },

    getStorage: (key) => {
        try {
            const data = localStorage.getItem(key);
            if (!data) return [];
            try {
                const parsed = JSON.parse(data);
                return Array.isArray(parsed) ? parsed : (typeof parsed === 'object' && parsed !== null ? parsed : []);
            } catch (e) { return []; }
        } catch (e) {
            console.error('Error reading storage', e);
            return [];
        }
    },

    // Timestamp da última escrita local (Echo suppression)
    lastWriteTime: {},

    saveRaw: (key, stringData) => {
        localStorage.setItem(key, stringData);
        Utils.lastWriteTime[key] = Date.now();
        if (Utils.Cloud) {
            try {
                const data = JSON.parse(stringData);
                Utils.Cloud.save(key, data);
            } catch (e) { }
        }
    },

    addToStorage: (key, item) => {
        try {
            const list = Utils.getStorage(key);
            list.push(item);
            const str = JSON.stringify(list);
            localStorage.setItem(key, str);
            Utils.lastWriteTime[key] = Date.now();
            if (Utils.Cloud) Utils.Cloud.save(key, list);
        } catch (e) { console.error(e); }
    },

    setStorage: (key, data) => {
        try {
            localStorage.setItem(key, JSON.stringify(data));
            Utils.lastWriteTime[key] = Date.now();
            if (Utils.Cloud) Utils.Cloud.save(key, data);
        } catch (e) { console.error(e); }
    },

    Cloud: {
        tenantId: localStorage.getItem('app_tenant_id') || 'parreiralog',

        setTenantId(id) {
            this.tenantId = id;
            localStorage.setItem('app_tenant_id', id);
            window.hasAttachedListeners = false;
        },

        // --- SAVE WITH CHUNKING SUPPORT ---
        async save(key, data) {
            if (!window.db && typeof firebase !== 'undefined') window.db = firebase.firestore();
            if (!window.db) return;

            try {
                const jsonContent = JSON.stringify(data);

                // Limite aprox 800KB para segurança (Firestore suporta 1MB)
                // Se OK, salva modo Legacy (Simples)
                if (jsonContent.length < 800000) {
                    await window.db.collection('tenants').doc(this.tenantId).collection('legacy_store').doc(key).set({
                        content: jsonContent,
                        updatedAt: firebase.firestore.FieldValue.serverTimestamp(),
                        isChunked: false
                    });
                    return;
                }

                // --- CHUNKING MODE ---
                console.log(`📦 Payload grande (${(jsonContent.length / 1024).toFixed(0)}kb). Iniciando particionamento...`);

                if (!Array.isArray(data)) {
                    window.showToast('❌ Erro: Dado muito grande e não particionável. Contate suporte.');
                    return;
                }

                // Chunk Size: 1000 itens (freight rows costumam ser leves)
                // Se cada row tem 200 bytes, 1000 = 200kb. Seguro.
                const chunkSize = 1000;
                const chunks = [];
                for (let i = 0; i < data.length; i += chunkSize) {
                    chunks.push(data.slice(i, i + chunkSize));
                }

                const batch = window.db.batch();

                // Salvar chunks: key_chunk_0, key_chunk_1...
                chunks.forEach((chunkData, index) => {
                    const chunkRef = window.db.collection('tenants').doc(this.tenantId).collection('legacy_store').doc(`${key}_chunk_${index}`);
                    batch.set(chunkRef, {
                        content: JSON.stringify(chunkData),
                        parentKey: key,
                        updatedAt: firebase.firestore.FieldValue.serverTimestamp()
                    });
                });

                // Commit chunks
                await batch.commit();

                // Atualizar Documento Mestre
                await window.db.collection('tenants').doc(this.tenantId).collection('legacy_store').doc(key).set({
                    content: '[]', // Placeholder
                    isChunked: true,
                    chunkCount: chunks.length,
                    totalItems: data.length,
                    updatedAt: firebase.firestore.FieldValue.serverTimestamp()
                });

                console.log(`✅ Salvo na nuvem em ${chunks.length} partes.`);
                if (window.showToast) window.showToast(`☁️ Dados grandes sincronizados em ${chunks.length} partes.`);

            } catch (e) {
                console.error("Cloud Save Error", e);
                if (window.showToast) window.showToast('❌ FALHA AO SALVAR NA NUVEM: ' + e.message);
            }
        },

        async loadAll() {
            if (!window.db) return false;
            this.listen();
            return true;
        },

        // --- HELPER: Puxar partes e remontar ---
        async loadChunks(key, count) {
            console.log(`📥 Baixando ${count} partes de ${key}...`);
            let fullData = [];
            const promises = [];

            for (let i = 0; i < count; i++) {
                promises.push(
                    window.db.collection('tenants').doc(this.tenantId).collection('legacy_store').doc(`${key}_chunk_${i}`).get()
                );
            }

            try {
                const docs = await Promise.all(promises);
                // Ordenar por índice só por garantia (mas Promise.all mantem ordem do array de promises)
                docs.forEach(d => {
                    if (d.exists) {
                        const chunkData = JSON.parse(d.data().content);
                        fullData = fullData.concat(chunkData);
                    }
                });
                console.log(`✅ ${key} reconstruído: ${fullData.length} itens.`);
                return fullData;
            } catch (e) {
                console.error("Erro ao baixar chunks", e);
                return [];
            }
        },

        // --- LÓGICA CENTRAL DE RECEBIMENTO DE DADOS ---
        processIncomingData(key, cloudContentString) {
            const localContent = localStorage.getItem(key);

            // 1. Anti-Echo (30s)
            const lastWrite = Utils.lastWriteTime[key] || 0;
            if (Date.now() - lastWrite < 30000) {
                console.log(`🛡️ [Anti-Echo] Ignorando nuvem para ${key} (escrita recente).`);
                return;
            }

            // 2. Anti-Rollback (Tamanho) - Apenas se não estivermos usando chunking (que garante integridade)
            // Se veio da nuvem valido, a gente confia.
            if (cloudContentString && cloudContentString.length > 2) {
                if (cloudContentString !== localContent) {
                    console.log(`🔄 [SaaS] Atualizando local: ${key}`);
                    localStorage.setItem(key, cloudContentString);

                    // UI Refresh
                    if (key === 'dispatches' && window.renderAppHistory) window.renderAppHistory();
                    if (key === 'freight_tables' && window.renderRulesList) window.renderRulesList();
                    if (key === 'carrier_configs' && window.renderCarrierConfigs) window.renderCarrierConfigs();
                    if (key === 'app_users' && window.renderUserList) window.renderUserList();
                    if (key === 'clients' && window.renderClientsList) window.renderClientsList();
                }
            } else {
                // Nuvem vazia.
                // Proteção: Só apagar local se realmente quisermos (por enquanto, PROTEÇÃO ATIVA: não apaga)
                if (localContent) {
                    console.warn(`⚠️ [SaaS] Nuvem vazia para ${key}, mas local existe. Mantendo local.`);
                }
            }
        },

        listen() {
            if (!window.db || window.hasAttachedListeners) return;
            window.hasAttachedListeners = true;

            const keys = ['dispatches', 'freight_tables', 'carrier_list', 'carrier_configs', 'company_data', 'app_users', 'carrier_info_v2', 'clients'];
            console.log(`📡 Iniciando Sync SaaS para Tenant: ${this.tenantId}`);

            keys.forEach(key => {
                window.db.collection('tenants').doc(this.tenantId).collection('legacy_store').doc(key).onSnapshot((doc) => {
                    if (doc.exists) {
                        const data = doc.data();

                        // SE FOR CHUNKED (Grande)
                        if (data.isChunked) {
                            console.log(`🧩 Detectado arquivo grande particionado: ${key}`);
                            this.loadChunks(key, data.chunkCount).then(fullArray => {
                                // Temos o array completo remontado. Converter para string para salvar.
                                this.processIncomingData(key, JSON.stringify(fullArray));
                            });
                            return;
                        }

                        // SE FOR NORMAL
                        const cloudContent = data.content;
                        this.processIncomingData(key, cloudContent);

                    } else {
                        // Doc Missing -> Tenta limpar local? (Desativado proteção)
                        this.processIncomingData(key, null);
                    }
                });
            });
            console.log("✅ SaaS: Listeners Ativos.");
        },

        listenToCloudChanges: (keys) => { }, // Legacy stub

        normalizeString: (str) => {
            if (!str) return '';
            return str.toString().normalize("NFD").replace(/[\u0300-\u036f]/g, "").trim().toUpperCase();
        }
    }
};

// ----------  UI HELPERS (Mantidos) ----------
function renderUserList() {
    const container = document.getElementById('userListContainer');
    if (!container) return;
    container.innerHTML = '';
    let users = Utils.getStorage('app_users') || [];
    if (!Array.isArray(users) || users.length === 0) {
        container.innerHTML = `<p style="color: var(--text-secondary); font-style: italic; text-align: center; padding: 1rem;">Nenhum usuário cadastrado.</p>`;
        return;
    }
    const ul = document.createElement('ul');
    ul.style.listStyle = 'none'; ul.style.padding = '0'; ul.style.margin = '0'; ul.style.display = 'flex'; ul.style.flexDirection = 'column'; ul.style.gap = '0.75rem';
    users.forEach((u, idx) => {
        const li = document.createElement('li');
        li.style = 'display:flex; justify-content:space-between; align-items:center; padding:0.75rem 1rem; background:var(--bg-card); border:1px solid var(--border-color); border-radius:var(--radius-md); transition:var(--transition);';
        li.onmouseenter = () => (li.style.transform = 'translateY(-2px)');
        li.onmouseleave = () => (li.style.transform = 'none');
        const info = document.createElement('div');
        info.innerHTML = `<div style="font-weight: 600; color: var(--text-primary);">${u.name}</div><div style="font-size: 0.85rem; color: var(--text-secondary);">Login: <code>${u.login}</code> | Nível: <span style="text-transform: capitalize;">${u.role}</span></div>`;
        li.appendChild(info);
        const actions = document.createElement('div');
        actions.style = 'display:flex; gap:0.5rem;';
        const editBtn = document.createElement('button');
        editBtn.className = 'btn btn-secondary'; editBtn.style = 'padding:0.4rem;'; editBtn.innerHTML = '<span class="material-icons-round" style="font-size:1.1rem;">edit</span>';
        editBtn.onclick = () => window.openUserEditModal(idx);
        actions.appendChild(editBtn);
        const delBtn = document.createElement('button');
        delBtn.className = 'btn btn-danger'; delBtn.style = 'padding:0.4rem;'; delBtn.innerHTML = '<span class="material-icons-round" style="font-size:1.1rem;">delete</span>';
        delBtn.onclick = () => {
            if (confirm(`Tem certeza que deseja remover o usuário "${u.name}"?`)) {
                const currentUsers = Utils.getStorage('app_users');
                currentUsers.splice(idx, 1);
                Utils.saveRaw('app_users', JSON.stringify(currentUsers));
                renderUserList();
            }
        };
        actions.appendChild(delBtn);
        li.appendChild(actions);
        ul.appendChild(li);
    });
    container.appendChild(ul);
}
window.renderUserList = renderUserList;

function openUserEditModal(idx) {
    const users = Utils.getStorage('app_users');
    const user = users[idx];
    if (!user) return;
    const nameEl = document.getElementById('regUserName') || document.getElementById('newUserName');
    const loginEl = document.getElementById('regUserLogin') || document.getElementById('newUserLogin');
    const passEl = document.getElementById('regUserPass') || document.getElementById('newUserPass');
    const roleEl = document.getElementById('regUserRole') || document.getElementById('newUserRole');
    if (nameEl) nameEl.value = user.name;
    if (loginEl) loginEl.value = user.login;
    if (passEl) passEl.value = user.pass;
    if (roleEl) roleEl.value = user.role;
    window.__editingUserIdx = idx;
    const btnSave = document.getElementById('btnSaveUser');
    if (btnSave) btnSave.innerText = 'Atualizar Usuário';
    if (nameEl) nameEl.focus();
}
window.openUserEditModal = openUserEditModal;
