# Documentação Técnica - ParreiraLog

Este arquivo serve como ponto de partida para novas sessões de desenvolvimento (Context Restoration).

## Visão Geral
Sistema Web para Cotação de Fretes, Montagem de Carga e Emissão de Romaneios.
- **Stack:** HTML5, CSS3, JavaScript (Vanilla).
- **Backend:** Google Firebase (Firestore) para banco de dados e sincronização.
- **Hospedagem:** Netlify (Deploy manual via Drag & Drop).

## Estrutura de Arquivos
- `index.html`: Arquivo único (SPA) contendo todas as views (Cotação, Dashboard, Configurações), Overlay de Login e estilos CSS inline/linkados.
- `app.js`: Lógica principal. Contém:
    - `calculateAndSave`: Core da cotação.
    - `confirmDispatch`: Gravação de despachos.
    - `renderDashboard`: Visualização por transportadora.
    - `generateRomaneioAction`: Geração de relatório para impressão.
    - `checkAuth` & Listeners de Login.
- `firebase-config.js`: Inicialização do Firebase e Auth Anônimo.
- `utils.js`: Helpers de formatação e `Utils.Cloud` (camada de abstração que salva LocalStorage + Firestore).
- `data.js`: Base de dados de Cidades/Clientes pré-carregada.

## Integração Nuvem (Firebase)
- **Projeto:** `parreiralog-91904`
- **Coleção Principal:** `legacy_store` (Armazena JSONs inteiros simulando LocalStorage: `dispatches`, `freight_tables`, `carrier_list`).
- **Autenticação:** O sistema usa `firebase.auth().signInAnonymously()` para validar conexão segura com o banco.
- **Login do Usuário:** O login visual (`admin`/`admin`) é gerenciado localmente no JS (`currentUser`), e é obrigatório para acessar a UI.

## Estado Atual (Último Deploy)
- Login obrigatório implementado (`loginOverlay` no HTML).
- Correção de `carrier` com trim/uppercase para garantir agrupamento no Dashboard.
- Impressão de Romaneio formatada como Planilha com coluna Valor.
- Sincronização automática ao abrir o app (`Utils.Cloud.loadAll`).

## Como Continuar
1. Ler este arquivo.
2. Ler `app.js` e `index.html` para contexto de código.
3. Para testar localmente: Abrir `index.html` no navegador.
4. Para publicar: Arrastar pasta `web` para Netlify Drop.
